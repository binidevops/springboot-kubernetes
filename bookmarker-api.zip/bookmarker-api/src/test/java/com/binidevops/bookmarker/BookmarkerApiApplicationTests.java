package com.binidevops.bookmarker;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookmarkerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
